
git clone --recursive https://github.com/GamerVII-NET/GamerVII.Notification.Avalonia.git ./src/GamerVII.Notification.Avalonia


git clone https://github.com/GamerVII-NET/Gml.Client.git ./src/Gml.Client
