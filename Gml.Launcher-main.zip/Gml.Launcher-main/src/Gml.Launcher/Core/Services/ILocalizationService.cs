﻿namespace Gml.Launcher.Core.Services;

public interface ILocalizationService
{
    string GetString(string key);
}
