﻿namespace Gml.Launcher.Models;

public record SettingsInfo(int GameWidth, int GameHeight, bool FullScreen, bool IsDynamicRam, double RamValue, string? LanguageCode)
{
}
