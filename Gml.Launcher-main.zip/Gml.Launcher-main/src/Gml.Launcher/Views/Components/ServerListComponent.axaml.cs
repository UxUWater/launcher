﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace Gml.Launcher.Views.Components;

public partial class ServerListComponent : UserControl
{
    public ServerListComponent()
    {
        InitializeComponent();
    }
}

