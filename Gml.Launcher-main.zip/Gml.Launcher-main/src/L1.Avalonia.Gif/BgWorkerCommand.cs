﻿namespace L1.Avalonia.Gif;

internal enum BgWorkerCommand
{
    Null,
    Play,
    Pause,
    Dispose
}
